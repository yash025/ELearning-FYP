import React, { Component } from 'react';
import './App.css';
import Login1 from '../components/Login1';
// import background from '../resources/images/login1.jpg';

class App extends Component {
  render() {
    return (
      <div className="LoginPage">
        <Login1/>
      </div>
    );
  }
}

export default App;
