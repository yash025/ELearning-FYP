import React from 'react';

const login = () => {
    const divStyle = {
        height: '143px',
        width: '186px',
        // backgroundColor: 'red',
        float: 'right',
        margin: '16px',
        marginTop: '530px',
        marginRight: '450px'
    }
    const paragraphStyle = {
        color: 'white'
    }

    return(
        <div style={divStyle}>
        <p style ={paragraphStyle}>Username:</p>
        <input type="text"/> 
        <p style ={paragraphStyle}>Password</p>
        <input type="password"/>
        <button type="submit" onClick=''>Login</button>
    </div>
    );

}

export default login;