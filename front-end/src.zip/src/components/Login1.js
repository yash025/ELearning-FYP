import React,{Component} from 'react';
// import axios from 'axios';

export default class Login extends Component{
    constructor(props){
        super(props);

        this.state={
            email: '',
            password: ''
        };
    }

    changeHandler = (event) => {
        this.setState({[event.target.name]: event.target.value})
    }

    submitHandler = () => {
        const {email, password} = this.state;
        // axios.post("", {userInfo : { email: email, password: password}});
    }

    render(){
        return(
            <div >
                <form onSubmit={this.submitHandler}>
                    <input 
                    type="email"
                    name="email"
                    placeholder="Email"
                    value={this.state.email}
                    onChange={this.changeHandler}
                    required/>

                    <input 
                    type="password"
                    name="password"
                    placeholder="Password"
                    value={this.state.password}
                    onChange={this.changeHandler}
                    required/>

                    <button type="submit">Login</button>
                    

                </form>
            </div>
        );
    }


}